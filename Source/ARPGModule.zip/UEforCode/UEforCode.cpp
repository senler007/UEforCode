// Copyright Epic Games, Inc. All Rights Reserved.

#include "UEforCode.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, UEforCode, "UEforCode" );
