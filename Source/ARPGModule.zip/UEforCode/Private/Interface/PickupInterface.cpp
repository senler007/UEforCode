// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface/PickupInterface.h"

// Add default functionality here for any IPickupInterface functions that are not pure virtual.

void IPickupInterface::SetOverlappingItem(AItems* Item)
{
}

void IPickupInterface::AddSouls(ASoul* Soul)
{

}

void IPickupInterface::AddGold(ATreasure* Gold)
{
}
